﻿using System;
using System.Numerics;

namespace Benchmark01
{
	public struct SDBX_OUTPUT
	{
		byte length;
		byte volume { get; set; }
		byte [] untouched;
		BigInteger factoradic;

		public void SetupFactoradic(byte[] pInputbytes, byte pVolume)
        {
			BigInteger bigNum = 0;
			SortedSet<byte> set = new SortedSet<byte>();
			var lastBytes = pInputbytes.TakeLast(256 - pVolume);
			var lastBytesArray = lastBytes.ToArray();
			var ok = false;

            for (int i = 0; i < lastBytes.Count(); i++)
            {
				set.Add(lastBytesArray[i]);
            }
			ok = lastBytesArray.Count() == 256 - pVolume;
			Console.WriteLine(ok);

            for (int i = 0; i < pInputbytes.Count(); i++)
            {
				bigNum = bigNum * i + pInputbytes[i];
            }
			this.length = (byte)bigNum.GetByteCount();

			Console.WriteLine(bigNum);
			Console.WriteLine(bigNum.GetBitLength() + "; " + bigNum.GetByteCount() );
			Console.WriteLine();
        }
		public byte[] Reversed()
        {
			return (byte[])factoradic.ToByteArray().Reverse();
        }
		public void setVolume(byte pVolume)
        {
			this.volume = pVolume;
        }
		public void addUntouchedBytes(byte[] pInputBytes, byte pVolume)
        {
			this.untouched = pInputBytes.Take(pVolume).ToArray();
        }
	}

	public struct SDBX_INPUT
    {
		byte[] inputData;
		SortedSet<byte> uniqueValues;

		public void AddInputData(byte[] pInputData)
        {
			this.inputData = pInputData;
			this.uniqueValues = new SortedSet<byte>();

            for (int i = 0; i < pInputData.Length; i++)
            {
				uniqueValues.Add(inputData[i]);
            }
        }
		public byte[] GetData()
        {
			return this.inputData;
        }

		public byte GetVolume()
        {
			return (byte)(256 - uniqueValues.Count);
        }
		public byte GetUnique()
        {
			return (byte)uniqueValues.Count;
        }
    }
}