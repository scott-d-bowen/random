﻿// SCOTTS AWESOME BENCHMARK
using System;
using System.Diagnostics;
using Benchmark01;


Console.WriteLine("Hello, World!");

// START THE STOPWATCH FOR CODE BENCHMARKING
System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
stopwatch.Start();

// LETS GENERATE SOME (16MB, as arrays of * 256 bytes of) RANDOM DATA:
byte[][] randomBytes = new byte[4096 / 256][]; // * [256] below;
var rng = new Random();

for (int i = 0; i < randomBytes.GetLength(0); i++) {
    randomBytes[i] = new List<byte>().ToArray();

    byte[] buffer = new byte[256];
    rng.NextBytes(buffer);
    randomBytes[i] = buffer;
    // OFF: Console.WriteLine(randomBytes[i].GetLength(0) );
}

// MEASURE TWICE, CUT ONCE
stopwatch.Stop();
Console.WriteLine(stopwatch.Elapsed);

// START THE STOPWATCH FOR CODE BENCHMARKING
stopwatch = new System.Diagnostics.Stopwatch();
stopwatch.Start();

// PERFORM SOME TASK
for (int i = 0; i < randomBytes.GetLength(0); i++)
{
    var x = randomBytes[i];
    SDBX_INPUT sdbxInput = new SDBX_INPUT();
    sdbxInput.AddInputData(x);
    var total = sdbxInput.GetVolume() + sdbxInput.GetUnique();

    SDBX_OUTPUT sdbxOutput = new SDBX_OUTPUT();
    sdbxOutput.setVolume(sdbxInput.GetVolume() );
    sdbxOutput.addUntouchedBytes(sdbxInput.GetData(), sdbxInput.GetVolume());
    sdbxOutput.SetupFactoradic(sdbxInput.GetData(), sdbxInput.GetVolume());

    Console.WriteLine(sdbxInput.GetVolume() + " + " + sdbxInput.GetUnique() + " = " + total);
    Console.WriteLine();
}

// MEASURE TWICE, CUT ONCE
stopwatch.Stop();
Console.WriteLine(stopwatch.Elapsed);
Console.WriteLine("Goodbye.");