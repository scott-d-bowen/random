﻿using System;
using System.Numerics;

namespace Benchmark01
{
	public struct BYTE_AND_OFFSET: IComparable
    {
		public byte value;
		public byte offset;

        public int CompareTo(object? obj)
        {
			return value.CompareTo(value: ((BYTE_AND_OFFSET)obj).value);
        }
    }

	public struct SDBX_OUTPUT
	{
		ushort length;
		byte volume { get; set; }
		byte [] untouched;
		BigInteger factoradic;

		public void SetupFactoradic(byte[] pInputbytes, byte pVolume)
        {
			BigInteger bigNum = 0;
			SortedSet<byte> set = new SortedSet<byte>();
			var lastBytes = pInputbytes.TakeLast(256 - pVolume);
			var lastBytesArray = lastBytes.ToArray();
			var ok = false;
			BYTE_AND_OFFSET[] byte_and_offset_array = new BYTE_AND_OFFSET[lastBytes.Count()];

			for (int i = 0; i < lastBytes.Count(); i++)
			{
				set.Add(lastBytesArray[i]);
				byte_and_offset_array[i].offset = (byte)i;
				byte_and_offset_array[i].value = lastBytesArray[i];
			}
			// SORT BAO ARRAY
			Array.Sort<BYTE_AND_OFFSET>(byte_and_offset_array);

			// DEBUG OUTPUT
			/* Console.WriteLine(byte_and_offset_array);
            for (int i = 0; i < byte_and_offset_array.Count(); i++)
            {
				Console.Write(byte_and_offset_array[i].offset + " " + byte_and_offset_array[i].value + "; ");
            }
			Console.WriteLine(); */

			// CHECK LENGTH [OK]
			ok = lastBytesArray.Count() == 256 - pVolume;
			Console.WriteLine(ok);

			// CREATE FACTORADIC
            for (int i = 0; i < lastBytes.Count(); i++)
            {
				bigNum = bigNum * i + byte_and_offset_array[i].offset;
            }
			this.length = (byte)bigNum.GetBitLength();

			Console.WriteLine(bigNum.GetBitLength() + "; " + bigNum.GetByteCount() );
			Console.WriteLine(bigNum);
		}
		public byte[] Reversed()
        {
			return (byte[])factoradic.ToByteArray().Reverse();
        }
		public void setVolume(byte pVolume)
        {
			this.volume = pVolume;
        }
		public void addUntouchedBytes(byte[] pInputBytes, byte pVolume)
        {
			this.untouched = pInputBytes.Take(pVolume).ToArray();
        }
	}

	public struct SDBX_INPUT
    {
		byte[] inputData;
		SortedSet<byte> uniqueValues;

		public void AddInputData(byte[] pInputData)
        {
			this.inputData = pInputData;
			this.uniqueValues = new SortedSet<byte>();

            for (int i = 0; i < pInputData.Length; i++)
            {
				uniqueValues.Add(inputData[i]);
            }
        }
		public byte[] GetData()
        {
			return this.inputData;
        }

		public byte GetVolume()
        {
			return (byte)(256 - uniqueValues.Count);
        }
		public byte GetUnique()
        {
			return (byte)uniqueValues.Count;
        }
    }
}