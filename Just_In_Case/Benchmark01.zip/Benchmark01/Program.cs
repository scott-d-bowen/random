﻿// SCOTTS AWESOME BENCHMARK
using System;
using System.Diagnostics;

Console.WriteLine("Hello, World!");

// START THE STOPWATCH FOR CODE BENCHMARKING
System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
stopwatch.Start();

// LETS GENERATE SOME (8GB, as 32 million * 256 bytes of) RANDOM DATA:
byte[][] randomBytes = new byte[33_554_432][]; // * [256] below;
var rng = new Random();

for (int i = 0; i < randomBytes.GetLength(0); i++) {
    randomBytes[i] = new List<byte>().ToArray();

    byte[] buffer = new byte[256];
    rng.NextBytes(buffer);
    randomBytes[i] = buffer;
    // OFF: Console.WriteLine(randomBytes[i].GetLength(0) );
}

// MEASURE TWICE, CUT ONCE
stopwatch.Stop();
Console.WriteLine(stopwatch.Elapsed);

// START THE STOPWATCH FOR CODE BENCHMARKING
stopwatch = new System.Diagnostics.Stopwatch();
stopwatch.Start();

// PERFORM SOME TASK
for (int i = 0; i < randomBytes.GetLength(0) - 1; i++)
{
    var x = randomBytes[i].ToArray().Except( randomBytes[i+1] );

    if (i % 65536 == 65534) {
        Console.Write(i + ": ");
        Console.WriteLine(x.GetHashCode().ToString() + "; " + x.ToArray().GetLength(0) );
    }
}

// MEASURE TWICE, CUT ONCE
stopwatch.Stop();
Console.WriteLine(stopwatch.Elapsed);
Console.WriteLine("Goodbye.");